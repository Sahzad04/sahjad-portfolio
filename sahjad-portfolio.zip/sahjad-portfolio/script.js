/* script.js */
console.log("Portfolio loaded successfully");
